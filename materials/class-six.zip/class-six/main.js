function calculateWinner(humanChoice, computerChoice){
  // calculate winner, given humanChoice and computerChoice
}

$(document).ready(function(){

  // create click event listener on boxes inside the #human element

    // when clicked:
      // get human choice

      // calculate computer choice with getComputerChoice() function

      // color the humanChoice and computerChoice boxes with colorHumanAndComputerChoices() function

      // calculate winner

      // if human winner, append the string 'Human' to #who-won
      // else if computer winner, append the string 'Computer' to #who-won
      // else, append the string 'Tie! Nobody'

      // Then, show #results-area
});
